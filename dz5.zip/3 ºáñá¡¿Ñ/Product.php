<?php

class Product
{
    private string $title;
    private float $price;
    private array $components = [];

    public function __construct(string $title, float $price, Product $components = null)
    {
        $this->title = $title;
        $this->price = $price + $components?->price;
        $this->components[] = $components;
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function setTitle(string $title): self
    {
        $this->title = $title;

        return $this;
    }

    public function getPrice(): float
    {
        return $this->price;
    }

    public function setPrice(float $price): self
    {
        $this->price = $price;

        return $this;
    }

    public function getComponents(): array
    {
        return $this->components;
    }

    public function setComponents(array $components): self
    {
        $this->components = $components;

        return $this;
    }
}
