<?php

class Cart
{
    private array $product = [];


    public function addProduct(Product $product): void
    {
        $this->product[$product->getTitle()] = $product;
    }

    public function removeProduct(Product $product): void
    {
        unset($this->product[$product->getTitle()]);
    }

    public function getProduct(): array
    {
        return $this->product;
    }

    public function sumPrice(): float
    {
        (float) $sum = 0;
        foreach ($this->product as $key) {
            $sum += $this->crutchPrice($key);
        }
        return $sum;
    }

    private function crutchPrice(Product $obj): float
    {
        return $obj->getPrice();
    }
}
