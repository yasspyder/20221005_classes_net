<?php

require_once 'Cart.php';
require_once 'Product.php';

//создание продукта мышь
$mouse = new Product('mouse', 15.38);

//создание продукта клавиатура + мышь
$keyboard = new Product('keyboard', 23.7, $mouse);

//создание продукта компьютер в наборе с набором клавиатура + мышь
$product = new Product('computer', 250.14, $keyboard);

//создание корзины
$cart = new Cart();

//добавление в корзину наборов продуктов компьютер и клавиатура
$cart->addProduct($product);
$cart->addProduct($keyboard);

//запрос стоимости всех товаров в корзине
print_r($cart->sumPrice());
