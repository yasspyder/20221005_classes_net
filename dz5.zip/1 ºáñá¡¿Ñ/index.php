 <?php
    require_once 'User.php';
    require_once 'Task.php';

    // создание нового юзера
    $user = new User('John', 'zlaia@john.net');
    // передча его в класс Task
    $task = new Task('Погулять', 2, $user);

    print_r($task);

    // задержка 3 сек для проверки обновления даты
    sleep(3);

    // проверка работоспособности отметки о выполнении
    $task->markAsDone();

    print_r($task);
