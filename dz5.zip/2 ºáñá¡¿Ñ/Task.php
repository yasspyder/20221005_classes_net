<?php

class Task
{
    private string $description;
    private DateTime $dateCreated;
    private DateTime $dateUpdated;
    private DateTime $dateDone;
    private int $priority;
    private bool $isDone;
    private User $user;
    private $comment = [];

    // создание задачи при инициализации
    function __construct(string $description, int $priority, User $user)
    {
        $this->description = $description;
        $this->priority = $priority;
        $this->user = $user;
        $this->dateCreated = new DateTime();
        $this->isDone = false;
    }

    // редактирование задачи
    public function setDescription($description)
    {

        $this->description = $description;
        $this->dateUpdated = new DateTime();

        return $this;
    }

    // просмотр задачи
    public function getDescription()
    {
        return $this->description;
    }

    // смотреть когда создана задача
    public function getDateCreated()
    {
        return $this->dateCreated;
    }

    // смотреть когда была обновлена задача
    public function getDateUpdated()
    {
        return $this->dateUpdated;
    }

    // смотреть когда была выполнена задача
    public function getDateDone()
    {
        return $this->dateDone;
    }

    // смотреть приоритет задачи
    public function getPriority(): int
    {
        return $this->priority;
    }

    // измененить приоритет задачи
    public function setPriority(int $priority): self
    {
        $this->priority = $priority;

        return $this;
    }

    // смотреть статус задачи
    public function isIsDone(): bool
    {
        return $this->isDone;
    }

    // смотреть исполнителя задачи
    public function getUser(): User
    {
        return $this->user;
    }

    // добавление комментария
    public function setComment($comment): self
    {
        $this->comment[] = $comment;

        return $this;
    }

    // смотреть комментарий
    public function getComment(): array
    {
        return $this->comment;
    }

    // сделать отметку о выполнении задачи
    public function markAsDone()
    {
        $this->isDone = true;
        $this->dateUpdated = new DateTime();
        $this->dateDone = new DateTime();
    }
}
