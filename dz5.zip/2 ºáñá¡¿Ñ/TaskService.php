<?php

class TaskService
{
    public static function addComment($author, $task, string $text, Task $tsk): void
    {
        $tsk->setComment(new Comment($author, $task, $text));
    }
}
