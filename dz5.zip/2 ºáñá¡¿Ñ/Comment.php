<?php

class Comment
{
    private $author;
    private $task;
    private string $text;

    function __construct($author, $task, $text)
    {
        $this->author = $author;
        $this->task = $task;
        $this->text = $text;
    }

    public function getAuthor()
    {
        return $this->author;
    }

    public function setAuthor($author): self
    {
        $this->author = $author;

        return $this;
    }

    public function getTask()
    {
        return $this->task;
    }

    public function setTask($task): self
    {
        $this->task = $task;

        return $this;
    }

    public function getText(): string
    {
        return $this->text;
    }

    public function setText(string $text): self
    {
        $this->text = $text;

        return $this;
    }
}