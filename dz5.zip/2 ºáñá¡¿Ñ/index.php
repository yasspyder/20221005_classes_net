<?php

require_once 'Comment.php';
require_once 'TaskService.php';
require_once 'Task.php';
require_once 'User.php';

// создание нового юзера
$name = (string) readline('Введите своё имя' . PHP_EOL);
$eml = (string) readline('Введите свой email' . PHP_EOL);

$user = new User($name, $eml);

// создание заметки и передача User в Task
$usr_tsk = (string) readline('Сделайте заметку о запланированной задаче' . PHP_EOL);
$priority = (int) readline('Какой приоритет у задачи, по пятибальной шкале?' . PHP_EOL);

$task = new Task($usr_tsk, $priority, $user);

print_r($task);

// задержка 3 сек для проверки обновления даты
echo "Через 3 секунды задача выполнится автоматически." . PHP_EOL;
sleep(3);

// проверка работоспособности метода выполнения задачи
$task->markAsDone();

print_r($task);

// добавление комментария к задаче
$com_txt = (string) readline('Добавьте комментарий к задаче:' . PHP_EOL);

$comm = TaskService::addComment(
    $user->getUsername(),
    $task->getDescription(),
    $com_txt,
    $task
);

print_r($task->getComment());
